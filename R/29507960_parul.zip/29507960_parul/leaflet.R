# map using Leaflet to show the location of the sites
library(leaflet)

#Reading the dataset into R
data <- read.csv("assignment-02-data-formated.csv")

#changing datatype of value to numeric
data =data %>% mutate(new_value=  gsub("%", "", paste(data$value)))
data=transform(data,new_value = as.numeric(new_value))

#leaflet map for site location
leaflet(data) %>% addTiles() %>% 
addMarkers(~longitude, ~latitude, label = ~as.character(location),labelOptions = labelOptions(noHide = T))